package day2_java_assignment;

public class Assign2Q3 
{
	public static void main(String[] args) 
	{	
		Account account=new SavingsAccount("ravi", "4343433434", 30000, 5, 1000);
		Account account2=new CurrentAccount("rajiv", "543545445", 500000, "AB1234", 50000);	
	}
}
